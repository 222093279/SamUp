import 'package:flutter_test/flutter_test.dart';
import 'package:student_accommodation_app/main.dart';

void main() {
  testWidgets('app shows branded splash then login screen', (tester) async {
    await tester.pumpWidget(const MyApp());

    expect(find.text('Campus Living'), findsOneWidget);
    expect(find.text('Student Accommodation'), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 1600));
    await tester.pumpAndSettle();

    expect(find.text('Welcome back'), findsOneWidget);
    expect(find.text('Sign in to continue'), findsOneWidget);
  });
}
