-- Required Supabase schema for the Campus Living accommodation app

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  contact_info TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_number TEXT NOT NULL UNIQUE,
  details TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE RESTRICT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  terms TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (end_date >= start_date)
);

CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id UUID REFERENCES public.contracts(id) ON DELETE CASCADE,
  amount NUMERIC(10,2) NOT NULL CHECK (amount >= 0),
  payment_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'Due' CHECK (status IN ('Paid', 'Due', 'Unpaid')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students are viewable by authenticated users"
ON public.students
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Students can be managed by authenticated users"
ON public.students
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Rooms are viewable by authenticated users"
ON public.rooms
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Rooms can be managed by authenticated users"
ON public.rooms
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Contracts are viewable by authenticated users"
ON public.contracts
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Contracts can be managed by authenticated users"
ON public.contracts
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Payments are viewable by authenticated users"
ON public.payments
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Payments can be managed by authenticated users"
ON public.payments
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

-- Optional: if you want a simple default status to help the UI
-- you can insert demo rows after creating the tables, for example:
-- INSERT INTO public.rooms (room_number, details) VALUES ('A-101', 'Single room');
-- INSERT INTO public.students (name, contact_info) VALUES ('Jane Doe', '+123456789');
