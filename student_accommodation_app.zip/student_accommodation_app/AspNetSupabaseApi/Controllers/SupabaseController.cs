using AspNetSupabaseApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AspNetSupabaseApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class SupabaseController : ControllerBase
{
    private readonly SupabaseDbClient _db;

    public SupabaseController(SupabaseDbClient db)
    {
        _db = db;
    }

    [HttpGet("health")]
    [AllowAnonymous]
    public IActionResult Health()
    {
        return Ok(new { status = "ok", project = "student_accommodation_app" });
    }

    [HttpGet("connection")]
    [AllowAnonymous]
    public async Task<IActionResult> ConnectionStatus()
    {
        try
        {
            var tableNames = new[] { "students", "rooms", "contracts", "payments" };
            var counts = new Dictionary<string, int>();

            foreach (var table in tableNames)
            {
                counts[table] = await _db.GetCountAsync(table);
            }

            return Ok(new
            {
                connected = true,
                project = "student_accommodation_app",
                database = "Supabase PostgreSQL",
                counts
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new
            {
                connected = false,
                error = ex.Message
            });
        }
    }

    [HttpGet("students")]
    public async Task<IActionResult> GetStudents()
    {
        var students = await _db.GetListAsync<StudentDto>("students");
        return Ok(students);
    }

    [HttpGet("rooms")]
    public async Task<IActionResult> GetRooms()
    {
        var rooms = await _db.GetListAsync<RoomDto>("rooms");
        return Ok(rooms);
    }

    [HttpGet("contracts")]
    public async Task<IActionResult> GetContracts()
    {
        var contracts = await _db.GetListAsync<ContractDto>("contracts");
        return Ok(contracts);
    }

    [HttpGet("payments")]
    public async Task<IActionResult> GetPayments()
    {
        var payments = await _db.GetListAsync<PaymentDto>("payments");
        return Ok(payments);
    }

    [HttpPost("students")]
    public async Task<IActionResult> CreateStudent([FromBody] StudentCreateDto dto)
    {
        var created = await _db.InsertAsync<StudentCreateDto, StudentDto>("students", dto);
        return Ok(created);
    }

    [HttpPut("students/{id}")]
    public async Task<IActionResult> UpdateStudent(string id, [FromBody] StudentCreateDto dto)
    {
        var updated = await _db.UpdateAsync("students", id, dto);
        return updated ? Ok(new { updated = true, id }) : NotFound();
    }

    [HttpDelete("students/{id}")]
    public async Task<IActionResult> DeleteStudent(string id)
    {
        var deleted = await _db.DeleteAsync("students", id);
        return deleted ? Ok(new { deleted = true }) : NotFound();
    }

    [HttpPost("rooms")]
    public async Task<IActionResult> CreateRoom([FromBody] RoomCreateDto dto)
    {
        var created = await _db.InsertAsync<RoomCreateDto, RoomDto>("rooms", dto);
        return Ok(created);
    }

    [HttpPut("rooms/{id}")]
    public async Task<IActionResult> UpdateRoom(string id, [FromBody] RoomCreateDto dto)
    {
        var updated = await _db.UpdateAsync("rooms", id, dto);
        return updated ? Ok(new { updated = true, id }) : NotFound();
    }

    [HttpDelete("rooms/{id}")]
    public async Task<IActionResult> DeleteRoom(string id)
    {
        var deleted = await _db.DeleteAsync("rooms", id);
        return deleted ? Ok(new { deleted = true }) : NotFound();
    }

    [HttpPost("contracts")]
    public async Task<IActionResult> CreateContract([FromBody] ContractCreateDto dto)
    {
        var created = await _db.InsertAsync<ContractCreateDto, ContractDto>("contracts", dto);
        return Ok(created);
    }

    [HttpPut("contracts/{id}")]
    public async Task<IActionResult> UpdateContract(string id, [FromBody] ContractCreateDto dto)
    {
        var updated = await _db.UpdateAsync("contracts", id, dto);
        return updated ? Ok(new { updated = true, id }) : NotFound();
    }

    [HttpDelete("contracts/{id}")]
    public async Task<IActionResult> DeleteContract(string id)
    {
        var deleted = await _db.DeleteAsync("contracts", id);
        return deleted ? Ok(new { deleted = true }) : NotFound();
    }

    [HttpPost("payments")]
    public async Task<IActionResult> CreatePayment([FromBody] PaymentCreateDto dto)
    {
        var created = await _db.InsertAsync<PaymentCreateDto, PaymentDto>("payments", dto);
        return Ok(created);
    }

    [HttpPut("payments/{id}")]
    public async Task<IActionResult> UpdatePayment(string id, [FromBody] PaymentCreateDto dto)
    {
        var updated = await _db.UpdateAsync("payments", id, dto);
        return updated ? Ok(new { updated = true, id }) : NotFound();
    }

    [HttpDelete("payments/{id}")]
    public async Task<IActionResult> DeletePayment(string id)
    {
        var deleted = await _db.DeleteAsync("payments", id);
        return deleted ? Ok(new { deleted = true }) : NotFound();
    }

    public class StudentDto
    {
        public string? id { get; set; }
        public string? name { get; set; }
        public string? contact_info { get; set; }
        public DateTime? created_at { get; set; }
    }

    public class StudentCreateDto
    {
        public string name { get; set; } = string.Empty;
        public string? contact_info { get; set; }
    }

    public class RoomDto
    {
        public string? id { get; set; }
        public string? room_number { get; set; }
        public string? details { get; set; }
        public DateTime? created_at { get; set; }
    }

    public class RoomCreateDto
    {
        public string room_number { get; set; } = string.Empty;
        public string? details { get; set; }
    }

    public class ContractDto
    {
        public string? id { get; set; }
        public string? student_id { get; set; }
        public string? room_id { get; set; }
        public DateTime? start_date { get; set; }
        public DateTime? end_date { get; set; }
        public string? terms { get; set; }
        public DateTime? created_at { get; set; }
    }

    public class ContractCreateDto
    {
        public string student_id { get; set; } = string.Empty;
        public string room_id { get; set; } = string.Empty;
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
        public string? terms { get; set; }
    }

    public class PaymentDto
    {
        public string? id { get; set; }
        public string? contract_id { get; set; }
        public decimal? amount { get; set; }
        public DateTime? payment_date { get; set; }
        public string? status { get; set; }
        public DateTime? created_at { get; set; }
    }

    public class PaymentCreateDto
    {
        public string contract_id { get; set; } = string.Empty;
        public decimal amount { get; set; }
        public DateTime payment_date { get; set; }
        public string status { get; set; } = "Due";
    }
}
