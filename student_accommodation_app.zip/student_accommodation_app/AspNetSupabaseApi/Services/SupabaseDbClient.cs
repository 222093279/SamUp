using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using AspNetSupabaseApi.Models;
using Microsoft.Extensions.Options;

namespace AspNetSupabaseApi.Services;

public class SupabaseDbClient
{
    private readonly HttpClient _httpClient;
    private readonly SupabaseSettings _settings;

    public SupabaseDbClient(HttpClient httpClient, IOptions<SupabaseSettings> settings)
    {
        _httpClient = httpClient;
        _settings = settings.Value;
    }

    public async Task<T?> GetOneAsync<T>(string table, string? select = "*")
    {
        var response = await GetAsync(table, select);
        if (!response.IsSuccessStatusCode)
        {
            throw new HttpRequestException($"Supabase GET failed: {response.StatusCode}");
        }

        var json = await response.Content.ReadAsStringAsync();
        var items = JsonSerializer.Deserialize<List<T>>(json, JsonOptions.Default);
        return items is { Count: > 0 } ? items[0] : default;
    }

    public async Task<List<T>> GetListAsync<T>(string table, string? select = "*", string? filter = null)
    {
        var response = await GetAsync(table, select, filter);
        if (!response.IsSuccessStatusCode)
        {
            throw new HttpRequestException($"Supabase GET failed: {response.StatusCode}");
        }

        var json = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<List<T>>(json, JsonOptions.Default) ?? new List<T>();
    }

    public async Task<int> GetCountAsync(string table)
    {
        var response = await GetAsync(table, "id", "limit=1");
        if (!response.IsSuccessStatusCode)
        {
            throw new HttpRequestException($"Supabase COUNT failed: {response.StatusCode}");
        }

        var json = await response.Content.ReadAsStringAsync();
        var items = JsonSerializer.Deserialize<List<IdOnly>>(json, JsonOptions.Default);
        return items?.Count ?? 0;
    }

    public async Task<TResponse?> InsertAsync<TRequest, TResponse>(string table, TRequest payload)
    {
        var response = await PostAsync(table, payload);
        if (!response.IsSuccessStatusCode)
        {
            var errorText = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"Supabase INSERT failed: {response.StatusCode}. {errorText}");
        }

        var json = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<TResponse>(json, JsonOptions.Default);
    }

    public async Task<List<TResponse>> InsertManyAsync<TRequest, TResponse>(string table, List<TRequest> payload)
    {
        var response = await PostAsync(table, payload);
        if (!response.IsSuccessStatusCode)
        {
            var errorText = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"Supabase INSERT failed: {response.StatusCode}. {errorText}");
        }

        var json = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<List<TResponse>>(json, JsonOptions.Default) ?? new List<TResponse>();
    }

    public async Task<bool> UpdateAsync<T>(string table, string id, T payload)
    {
        var content = JsonSerializer.Serialize(payload, JsonOptions.Default);
        var request = new HttpRequestMessage(HttpMethod.Patch, BuildUrl(table) + $"?id=eq.{id}")
        {
            Content = new StringContent(content, Encoding.UTF8, "application/json")
        };

        ApplyHeaders(request);
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> DeleteAsync(string table, string id)
    {
        var url = BuildUrl(table);
        var request = new HttpRequestMessage(HttpMethod.Delete, url + $"?id=eq.{id}");
        ApplyHeaders(request);

        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    private async Task<HttpResponseMessage> GetAsync(string table, string? select = "*", string? filter = null)
    {
        var url = BuildUrl(table);
        if (!string.IsNullOrWhiteSpace(select))
        {
            url += $"?select={Uri.EscapeDataString(select)}";
        }

        if (!string.IsNullOrWhiteSpace(filter))
        {
            url += $"&{filter}";
        }

        var request = new HttpRequestMessage(HttpMethod.Get, url);
        ApplyHeaders(request);
        return await _httpClient.SendAsync(request);
    }

    private async Task<HttpResponseMessage> PostAsync<T>(string table, T payload)
    {
        var content = JsonSerializer.Serialize(payload, JsonOptions.Default);
        var request = new HttpRequestMessage(HttpMethod.Post, BuildUrl(table))
        {
            Content = new StringContent(content, Encoding.UTF8, "application/json")
        };

        ApplyHeaders(request);
        return await _httpClient.SendAsync(request);
    }

    private string BuildUrl(string table)
    {
        return $"{_settings.Url.TrimEnd('/')}/rest/v1/{table.TrimStart('/')}";
    }

    private void ApplyHeaders(HttpRequestMessage request)
    {
        var key = !string.IsNullOrWhiteSpace(_settings.ServiceRoleKey)
            ? _settings.ServiceRoleKey
            : _settings.AnonKey;

        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        request.Headers.Add("apikey", key);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", key);
    }

    private static class JsonOptions
    {
        public static readonly JsonSerializerOptions Default = new()
        {
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
        };
    }

    private class IdOnly
    {
        public string? id { get; set; }
    }
}
