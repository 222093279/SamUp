// lib/secrets.dart
final String supabaseUrl = 'https://phrzklmjwvhoccgojlqf.supabase.co';
final String supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBocnprbG1qd3Zob2NjZ29qbHFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc1NzYzMDcsImV4cCI6MjEwMzE1MjMwN30.f6yLpKdPVK9CrfihkMhcJtvlY1v-5Ap0xBollqJThyY';

final String backendBaseUrl = 'http://10.0.2.2:5099';
