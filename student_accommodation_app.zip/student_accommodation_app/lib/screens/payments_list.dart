import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/backend_api.dart';
import 'add_edit_payment.dart';

class PaymentsListScreen extends StatefulWidget {
  const PaymentsListScreen({super.key});

  @override
  State<PaymentsListScreen> createState() => _PaymentsListScreenState();
}

class _PaymentsListScreenState extends State<PaymentsListScreen> {
  late Future<List<Map<String, dynamic>>> paymentsFuture;

  @override
  void initState() {
    super.initState();
    paymentsFuture = fetchPayments();
  }

  Future<List<Map<String, dynamic>>> fetchPayments() async {
    final api = BackendApiService();
    try {
      final payments = await api.getPayments();

      for (final payment in payments) {
        final paymentDate = DateTime.tryParse(payment['payment_date']?.toString() ?? '');
        final rawStatus = payment['status']?.toString() ?? 'Due';

        if (rawStatus != 'Paid' &&
            paymentDate != null &&
            paymentDate.isBefore(DateTime.now())) {
          await Supabase.instance.client
              .from('payments')
              .update({'status': 'Unpaid'}).eq('id', payment['id']);
          payment['status'] = 'Unpaid';
        }
      }

      return payments;
    } catch (_) {
      final response = await Supabase.instance.client
          .from('payments')
          .select('*, contracts(*, students(*))');

      final payments = List<Map<String, dynamic>>.from(response as List);

      for (final payment in payments) {
        final paymentDate = DateTime.tryParse(payment['payment_date']?.toString() ?? '');
        final rawStatus = payment['status']?.toString() ?? 'Due';

        if (rawStatus != 'Paid' &&
            paymentDate != null &&
            paymentDate.isBefore(DateTime.now())) {
          await Supabase.instance.client
              .from('payments')
              .update({'status': 'Unpaid'}).eq('id', payment['id']);
          payment['status'] = 'Unpaid';
        }
      }

      return payments;
    }
  }

  Future<void> deletePayment(String id) async {
    try {
      final api = BackendApiService();
      await api.deletePayment(id);
      if (!mounted) return;
      setState(() {
        paymentsFuture = fetchPayments();
      });
    } catch (e) {
      try {
        await Supabase.instance.client.from('payments').delete().eq('id', id);
      } catch (fallbackError) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting payment: $fallbackError')),
        );
        return;
      }
      if (!mounted) return;
      setState(() {
        paymentsFuture = fetchPayments();
      });
    }
  }

  Widget _buildSummaryHeader(int totalPayments) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1D4ED8), Color(0xFF2563EB)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withValues(alpha: 0.22),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.payments_outlined, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Billing overview',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$totalPayments payment entries',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.9),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120),
        child: AppBar(
          title: const Text('Payments'),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFEFF6FF), Color(0xFFF8FAFC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: paymentsFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }

            final payments = snapshot.data ?? [];
            if (payments.isEmpty) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.payments_outlined,
                        size: 46,
                        color: Color(0xFF2563EB),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'No payments found.',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Record the first payment for a resident.',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              );
            }

            return Column(
              children: [
                _buildSummaryHeader(payments.length),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                    itemCount: payments.length,
                    itemBuilder: (context, index) {
                      final payment = payments[index];
                      final amount = payment['amount'];
                      final date = payment['payment_date'];
                      final paymentDate = DateTime.tryParse(date?.toString() ?? '');
                      final rawStatus = payment['status']?.toString() ?? 'Due';
                      final status = rawStatus == 'Paid'
                          ? 'Paid'
                          : (paymentDate != null && paymentDate.isBefore(DateTime.now().subtract(const Duration(days: 1)))
                              ? 'Unpaid'
                              : rawStatus);
                      final studentName = payment['contracts']?['students']?['name'] ?? 'Unknown';

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.75),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.8),
                            width: 1.1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.blue.withValues(alpha: 0.08),
                              blurRadius: 18,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          leading: CircleAvatar(
                            radius: 24,
                            backgroundColor: const Color(0xFFE0EDFF),
                            child: const Icon(
                              Icons.payments_outlined,
                              color: Color(0xFF2563EB),
                            ),
                          ),
                          title: Text('Student: $studentName'),
                          subtitle: Text('Amount: $amount\nDate: $date\nStatus: $status'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Tooltip(
                                message: 'Edit payment',
                                child: IconButton(
                                  icon: const Icon(Icons.edit_outlined),
                                  onPressed: () async {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => AddEditPaymentScreen(payment: payment),
                                      ),
                                    );
                                    setState(() {
                                      paymentsFuture = fetchPayments();
                                    });
                                  },
                                ),
                              ),
                              Tooltip(
                                message: 'Delete payment',
                                child: IconButton(
                                  icon: const Icon(Icons.delete_outline),
                                  onPressed: () => deletePayment(payment['id'].toString()),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddEditPaymentScreen()),
          );
          setState(() {
            paymentsFuture = fetchPayments();
          });
        },
        icon: const Icon(Icons.add),
        label: const Text('Add payment'),
      ),
    );
  }
}
