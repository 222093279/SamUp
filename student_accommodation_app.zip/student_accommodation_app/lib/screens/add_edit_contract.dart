import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/backend_api.dart';

class AddEditContractScreen extends StatefulWidget {
  final Map<String, dynamic>? contract;
  final String? selectedStudentId;
  final String? selectedRoomId;

  const AddEditContractScreen({
    super.key,
    this.contract,
    this.selectedStudentId,
    this.selectedRoomId,
  });

  @override
  State<AddEditContractScreen> createState() => _AddEditContractScreenState();
}

class _AddEditContractScreenState extends State<AddEditContractScreen> {
  String? studentId;
  String? roomId;
  DateTime? startDate;
  DateTime? endDate;
  final TextEditingController termsController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.contract != null) {
      studentId = widget.contract!['student_id']?.toString();
      roomId = widget.contract!['room_id']?.toString();
      startDate = DateTime.tryParse(widget.contract!['start_date']?.toString() ?? '');
      endDate = DateTime.tryParse(widget.contract!['end_date']?.toString() ?? '');
      termsController.text = widget.contract!['terms'] ?? '';
    } else {
      studentId = widget.selectedStudentId;
      roomId = widget.selectedRoomId;
    }
  }

  Future<void> saveContract() async {
    if (studentId == null || roomId == null || startDate == null || endDate == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields')),
      );
      return;
    }

    final data = {
      'student_id': studentId,
      'room_id': roomId,
      'start_date': startDate!.toIso8601String().split('T')[0],
      'end_date': endDate!.toIso8601String().split('T')[0],
      'terms': termsController.text,
    };

    try {
      final api = BackendApiService();
      if (widget.contract == null) {
        await api.createContract(data);
      } else {
        await api.updateContract(widget.contract!['id'], data);
      }
      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      try {
        if (widget.contract == null) {
          await Supabase.instance.client.from('contracts').insert(data);
        } else {
          await Supabase.instance.client
              .from('contracts')
              .update(data)
              .eq('id', widget.contract!['id']);
        }
        if (!mounted) return;
        Navigator.pop(context);
      } catch (fallbackError) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $fallbackError')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.contract != null;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120),
        child: AppBar(
          title: Text(isEdit ? 'Edit Contract' : 'Add Contract'),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFEFF6FF), Color(0xFFF8FAFC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(24, 110, 24, 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.72),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.7),
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blue.withValues(alpha: 0.12),
                      blurRadius: 24,
                      offset: const Offset(0, 12),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        width: 84,
                        height: 84,
                        margin: const EdgeInsets.only(bottom: 14),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE0EDFF),
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: const Icon(
                          Icons.description_outlined,
                          size: 42,
                          color: Color(0xFF2563EB),
                        ),
                      ),
                      Text(
                        isEdit ? 'Update contract' : 'Create contract',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 24),
                      FutureBuilder<List<Map<String, dynamic>>>(
                        future: Supabase.instance.client.from('students').select('id, name'),
                        builder: (_, snapshot) {
                          if (snapshot.connectionState == ConnectionState.waiting) {
                            return const Center(child: CircularProgressIndicator());
                          }
                          if (snapshot.hasError || !snapshot.hasData) {
                            return const Text('Error fetching students');
                          }

                          final students = snapshot.data!;
                          return DropdownButtonFormField<String>(
                            initialValue: studentId,
                            decoration: const InputDecoration(labelText: 'Student'),
                            items: students
                                .map((student) => DropdownMenuItem<String>(
                                      value: student['id']?.toString(),
                                      child: Text(student['name']?.toString() ?? 'Unknown'),
                                    ))
                                .toList(),
                            onChanged: (val) => setState(() => studentId = val),
                          );
                        },
                      ),
                      const SizedBox(height: 16),
                      FutureBuilder<List<Map<String, dynamic>>>(
                        future: Supabase.instance.client.from('rooms').select('id, room_number'),
                        builder: (_, snapshot) {
                          if (snapshot.connectionState == ConnectionState.waiting) {
                            return const Center(child: CircularProgressIndicator());
                          }
                          if (snapshot.hasError || !snapshot.hasData) {
                            return const Text('Error fetching rooms');
                          }

                          final rooms = snapshot.data!;
                          return DropdownButtonFormField<String>(
                            initialValue: roomId,
                            decoration: const InputDecoration(labelText: 'Room'),
                            items: rooms
                                .map((room) => DropdownMenuItem<String>(
                                      value: room['id']?.toString(),
                                      child: Text(room['room_number']?.toString() ?? 'Unknown'),
                                    ))
                                .toList(),
                            onChanged: (val) => setState(() => roomId = val),
                          );
                        },
                      ),
                      const SizedBox(height: 16),
                      ListTile(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        tileColor: Colors.white.withValues(alpha: 0.56),
                        title: Text(
                          startDate == null
                              ? 'Start Date'
                              : 'Start: ${startDate!.toLocal().toString().split(' ')[0]}',
                        ),
                        trailing: const Icon(Icons.calendar_today_outlined),
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: startDate ?? DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (picked != null && mounted) {
                            setState(() => startDate = picked);
                          }
                        },
                      ),
                      const SizedBox(height: 12),
                      ListTile(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        tileColor: Colors.white.withValues(alpha: 0.56),
                        title: Text(
                          endDate == null
                              ? 'End Date'
                              : 'End: ${endDate!.toLocal().toString().split(' ')[0]}',
                        ),
                        trailing: const Icon(Icons.calendar_today_outlined),
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: endDate ?? DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (picked != null && mounted) {
                            setState(() => endDate = picked);
                          }
                        },
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: termsController,
                        maxLines: 3,
                        decoration: const InputDecoration(labelText: 'Terms & Conditions'),
                      ),
                      const SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: saveContract,
                        child: Text(isEdit ? 'Update' : 'Add'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
