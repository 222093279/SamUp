import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/backend_api.dart';

class AddEditRoomScreen extends StatefulWidget {
  final Map<String, dynamic>? room;

  const AddEditRoomScreen({
    super.key,
    this.room,
  });

  @override
  State<AddEditRoomScreen> createState() => _AddEditRoomScreenState();
}

class _AddEditRoomScreenState extends State<AddEditRoomScreen> {
  final TextEditingController roomNumberController = TextEditingController();
  final TextEditingController detailsController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.room != null) {
      roomNumberController.text = widget.room!['room_number']?.toString() ?? '';
      detailsController.text = widget.room!['details']?.toString() ?? '';
    }
  }

  Future<void> saveRoom() async {
    final roomNumber = roomNumberController.text.trim();
    final details = detailsController.text.trim();

    if (roomNumber.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Room number cannot be empty')),
      );
      return;
    }

    final data = {
      'room_number': roomNumber,
      'details': details,
    };

    try {
      final api = BackendApiService();
      if (widget.room == null) {
        await api.createRoom(data);
      } else {
        await api.updateRoom(widget.room!['id'], data);
      }
      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      try {
        if (widget.room == null) {
          await Supabase.instance.client.from('rooms').insert(data);
        } else {
          await Supabase.instance.client
              .from('rooms')
              .update(data)
              .eq('id', widget.room!['id']);
        }
        if (!mounted) return;
        Navigator.pop(context);
      } catch (fallbackError) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $fallbackError')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.room != null;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120),
        child: AppBar(
          title: Text(isEdit ? 'Edit Room' : 'Add Room'),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFEFF6FF), Color(0xFFF8FAFC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 110, 24, 24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.72),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.7),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue.withValues(alpha: 0.12),
                        blurRadius: 24,
                        offset: const Offset(0, 12),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          width: 84,
                          height: 84,
                          margin: const EdgeInsets.only(bottom: 14),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE0EDFF),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          child: const Icon(
                            Icons.meeting_room_rounded,
                            size: 42,
                            color: Color(0xFF2563EB),
                          ),
                        ),
                        Text(
                          isEdit ? 'Update room details' : 'Add a room',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 24),
                        TextField(
                          controller: roomNumberController,
                          decoration: const InputDecoration(labelText: 'Room Number'),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: detailsController,
                          maxLines: 3,
                          decoration: const InputDecoration(labelText: 'Details'),
                        ),
                        const SizedBox(height: 24),
                        ElevatedButton(
                          onPressed: saveRoom,
                          child: Text(isEdit ? 'Update' : 'Add'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
