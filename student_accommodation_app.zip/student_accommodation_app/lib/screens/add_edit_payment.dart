import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/backend_api.dart';

class AddEditPaymentScreen extends StatefulWidget {
  final Map<String, dynamic>? payment;
  final String? contractId;

  const AddEditPaymentScreen({
    super.key,
    this.payment,
    this.contractId,
  });

  @override
  State<AddEditPaymentScreen> createState() => _AddEditPaymentScreenState();
}

class _AddEditPaymentScreenState extends State<AddEditPaymentScreen> {
  final TextEditingController amountController = TextEditingController();
  String? contractId;
  String? status;
  DateTime? paymentDate;

  @override
  void initState() {
    super.initState();
    contractId = widget.contractId ?? widget.payment?['contract_id']?.toString();
    if (widget.payment != null) {
      amountController.text = widget.payment!['amount']?.toString() ?? '';
      status = widget.payment!['status']?.toString();
      paymentDate = DateTime.tryParse(widget.payment!['payment_date']?.toString() ?? '');
    }
  }

  Future<void> savePayment() async {
    final amount = double.tryParse(amountController.text);
    if (amount == null || paymentDate == null || status == null || contractId == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a contract and fill all fields')),
      );
      return;
    }

    final normalizedStatus = paymentDate!.isBefore(DateTime.now()) && status == 'Due'
        ? 'Unpaid'
        : status;

    final data = {
      'contract_id': contractId,
      'amount': amount,
      'payment_date': paymentDate!.toIso8601String().split('T')[0],
      'status': normalizedStatus,
    };

    try {
      final api = BackendApiService();
      if (widget.payment == null) {
        await api.createPayment(data);
      } else {
        await api.updatePayment(widget.payment!['id'], data);
      }
      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      try {
        if (widget.payment == null) {
          await Supabase.instance.client.from('payments').insert(data);
        } else {
          await Supabase.instance.client
              .from('payments')
              .update(data)
              .eq('id', widget.payment!['id']);
        }
        if (!mounted) return;
        Navigator.pop(context);
      } catch (fallbackError) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $fallbackError')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.payment != null;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120),
        child: AppBar(
          title: Text(isEdit ? 'Edit Payment' : 'Add Payment'),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFEFF6FF), Color(0xFFF8FAFC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 110, 24, 24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.72),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.7),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue.withValues(alpha: 0.12),
                        blurRadius: 24,
                        offset: const Offset(0, 12),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          width: 84,
                          height: 84,
                          margin: const EdgeInsets.only(bottom: 14),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE0EDFF),
                            borderRadius: BorderRadius.circular(24),
                          ),
                          child: const Icon(
                            Icons.payments_outlined,
                            size: 42,
                            color: Color(0xFF2563EB),
                          ),
                        ),
                        Text(
                          isEdit ? 'Update payment' : 'Add payment',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 24),
                        TextField(
                          controller: amountController,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          decoration: const InputDecoration(labelText: 'Amount'),
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField<String>(
                          initialValue: status,
                          decoration: const InputDecoration(labelText: 'Status'),
                          items: ['Paid', 'Due', 'Unpaid']
                              .map((value) => DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  ))
                              .toList(),
                          onChanged: (val) => setState(() => status = val),
                        ),
                        const SizedBox(height: 16),
                        ListTile(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          tileColor: Colors.white.withValues(alpha: 0.56),
                          title: Text(
                            paymentDate == null
                                ? 'Payment Date'
                                : 'Date: ${paymentDate!.toLocal().toString().split(' ')[0]}',
                          ),
                          trailing: const Icon(Icons.calendar_today_outlined),
                          onTap: () async {
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: paymentDate ?? DateTime.now(),
                              firstDate: DateTime(2000),
                              lastDate: DateTime(2100),
                            );
                            if (picked != null && mounted) {
                              setState(() => paymentDate = picked);
                            }
                          },
                        ),
                        const SizedBox(height: 24),
                        FutureBuilder<List<Map<String, dynamic>>>(
                          future: Supabase.instance.client
                              .from('contracts')
                              .select('id, students!inner(name), rooms!inner(room_number)'),
                          builder: (_, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return const Center(child: CircularProgressIndicator());
                            }
                            if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
                              return const Text('No contracts available. Create a contract first.');
                            }

                            final contracts = snapshot.data!;
                            return DropdownButtonFormField<String>(
                              initialValue: contractId,
                              decoration: const InputDecoration(labelText: 'Contract'),
                              items: contracts
                                  .map((contract) => DropdownMenuItem<String>(
                                        value: contract['id']?.toString(),
                                        child: Text(
                                          '${contract['students']?['name'] ?? 'Unknown'} - ${contract['rooms']?['room_number'] ?? 'Unknown'}',
                                        ),
                                      ))
                                  .toList(),
                              onChanged: (val) => setState(() => contractId = val),
                            );
                          },
                        ),
                        const SizedBox(height: 24),
                        ElevatedButton(
                          onPressed: savePayment,
                          child: Text(isEdit ? 'Update' : 'Add'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
