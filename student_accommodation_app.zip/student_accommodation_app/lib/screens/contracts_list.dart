import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/backend_api.dart';
import 'add_edit_contract.dart';

class ContractsListScreen extends StatefulWidget {
  const ContractsListScreen({super.key});

  @override
  State<ContractsListScreen> createState() => _ContractsListScreenState();
}

class _ContractsListScreenState extends State<ContractsListScreen> {
  late Future<List<Map<String, dynamic>>> contractsFuture;

  @override
  void initState() {
    super.initState();
    contractsFuture = fetchContracts();
  }

  Future<List<Map<String, dynamic>>> fetchContracts() async {
    final api = BackendApiService();
    try {
      return await api.getContracts();
    } catch (_) {
      final response = await Supabase.instance.client
          .from('contracts')
          .select('*, students!inner(*), rooms!inner(*)');
      return List<Map<String, dynamic>>.from(response as List);
    }
  }

  Future<void> deleteContract(String id) async {
    try {
      final api = BackendApiService();
      await api.deleteContract(id);
      if (!mounted) return;
      setState(() {
        contractsFuture = fetchContracts();
      });
    } catch (e) {
      try {
        await Supabase.instance.client.from('contracts').delete().eq('id', id);
      } catch (fallbackError) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting contract: $fallbackError')),
        );
        return;
      }
      if (!mounted) return;
      setState(() {
        contractsFuture = fetchContracts();
      });
    }
  }

  Widget _buildSummaryHeader(int totalContracts) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1D4ED8), Color(0xFF2563EB)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withValues(alpha: 0.22),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.description_outlined, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Tenancy records',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$totalContracts live agreements',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.9),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(120),
        child: AppBar(
          title: const Text('Contracts'),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFEFF6FF), Color(0xFFF8FAFC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: contractsFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }

            final contracts = snapshot.data ?? [];
            if (contracts.isEmpty) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.description_outlined,
                        size: 46,
                        color: Color(0xFF2563EB),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'No contracts found.',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Create the first tenancy contract for a resident.',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              );
            }

            return Column(
              children: [
                _buildSummaryHeader(contracts.length),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                    itemCount: contracts.length,
                    itemBuilder: (context, index) {
                      final contract = contracts[index];
                      final studentName = contract['students']?['name'] ?? 'Unknown';
                      final roomNumber = contract['rooms']?['room_number'] ?? 'Unknown';

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.75),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.8),
                            width: 1.1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.blue.withValues(alpha: 0.08),
                              blurRadius: 18,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          leading: CircleAvatar(
                            radius: 24,
                            backgroundColor: const Color(0xFFE0EDFF),
                            child: const Icon(
                              Icons.description_outlined,
                              color: Color(0xFF2563EB),
                            ),
                          ),
                          title: Text('Student: $studentName'),
                          subtitle: Text(
                            'Room: $roomNumber\nPeriod: ${contract['start_date']} to ${contract['end_date']}',
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Tooltip(
                                message: 'Edit contract',
                                child: IconButton(
                                  icon: const Icon(Icons.edit_outlined),
                                  onPressed: () async {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => AddEditContractScreen(contract: contract),
                                      ),
                                    );
                                    setState(() {
                                      contractsFuture = fetchContracts();
                                    });
                                  },
                                ),
                              ),
                              Tooltip(
                                message: 'Delete contract',
                                child: IconButton(
                                  icon: const Icon(Icons.delete_outline),
                                  onPressed: () => deleteContract(contract['id'].toString()),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddEditContractScreen()),
          );
          setState(() {
            contractsFuture = fetchContracts();
          });
        },
        icon: const Icon(Icons.add),
        label: const Text('Add contract'),
      ),
    );
  }
}
