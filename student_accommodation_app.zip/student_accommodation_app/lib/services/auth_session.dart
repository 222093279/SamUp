import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthSessionService {
  const AuthSessionService();

  static bool hasValidSession() {
    final session = Supabase.instance.client.auth.currentSession;
    return session != null && session.accessToken.isNotEmpty;
  }

  static String? getAccessToken() {
    return Supabase.instance.client.auth.currentSession?.accessToken;
  }

  static String? getCurrentUserEmail() {
    return Supabase.instance.client.auth.currentUser?.email;
  }

  static Future<void> ensureAuthenticated(BuildContext context) async {
    final session = Supabase.instance.client.auth.currentSession;
    if (session == null || session.accessToken.isEmpty) {
      if (context.mounted) {
        Navigator.of(context).pushReplacementNamed('/login');
      }
      throw Exception('User is not authenticated. Please log in again.');
    }
  }
}
