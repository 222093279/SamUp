import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';

import '../secrets.dart';
import 'auth_session.dart';

class BackendApiService {
  BackendApiService();

  void _ensureAuthenticated() {
    if (!AuthSessionService.hasValidSession()) {
      throw Exception('User is not authenticated. Please log in again.');
    }
  }

  Map<String, String> _authHeaders() {
    _ensureAuthenticated();
    final token = AuthSessionService.getAccessToken();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  Future<List<Map<String, dynamic>>> getStudents() async {
    return _getList('/api/supabase/students');
  }

  Future<List<Map<String, dynamic>>> getRooms() async {
    return _getList('/api/supabase/rooms');
  }

  Future<List<Map<String, dynamic>>> getContracts() async {
    return _getList('/api/supabase/contracts');
  }

  Future<List<Map<String, dynamic>>> getPayments() async {
    return _getList('/api/supabase/payments');
  }

  Future<void> createStudent(Map<String, dynamic> data) async {
    await _sendRequest('POST', '/api/supabase/students', data);
  }

  Future<void> updateStudent(String id, Map<String, dynamic> data) async {
    await _sendRequest('PUT', '/api/supabase/students/$id', data);
  }

  Future<void> deleteStudent(String id) async {
    await _sendRequest('DELETE', '/api/supabase/students/$id');
  }

  Future<void> createRoom(Map<String, dynamic> data) async {
    await _sendRequest('POST', '/api/supabase/rooms', data);
  }

  Future<void> updateRoom(String id, Map<String, dynamic> data) async {
    await _sendRequest('PUT', '/api/supabase/rooms/$id', data);
  }

  Future<void> deleteRoom(String id) async {
    await _sendRequest('DELETE', '/api/supabase/rooms/$id');
  }

  Future<void> createContract(Map<String, dynamic> data) async {
    await _sendRequest('POST', '/api/supabase/contracts', data);
  }

  Future<void> updateContract(String id, Map<String, dynamic> data) async {
    await _sendRequest('PUT', '/api/supabase/contracts/$id', data);
  }

  Future<void> deleteContract(String id) async {
    await _sendRequest('DELETE', '/api/supabase/contracts/$id');
  }

  Future<void> createPayment(Map<String, dynamic> data) async {
    await _sendRequest('POST', '/api/supabase/payments', data);
  }

  Future<void> updatePayment(String id, Map<String, dynamic> data) async {
    await _sendRequest('PUT', '/api/supabase/payments/$id', data);
  }

  Future<void> deletePayment(String id) async {
    await _sendRequest('DELETE', '/api/supabase/payments/$id');
  }

  Future<void> _sendRequest(String method, String endpoint, [Map<String, dynamic>? body]) async {
    final uri = Uri.parse('$backendBaseUrl$endpoint');
    final headers = _authHeaders();

    final response = switch (method) {
      'POST' => await http.post(uri, headers: headers, body: jsonEncode(body ?? {})),
      'PUT' => await http.put(uri, headers: headers, body: jsonEncode(body ?? {})),
      'DELETE' => await http.delete(uri, headers: headers),
      _ => throw UnsupportedError('Unsupported HTTP method: $method'),
    };

    if (response.statusCode != 200 && response.statusCode != 201 && response.statusCode != 204) {
      throw Exception('$method $endpoint failed: ${response.statusCode}');
    }
  }

  Future<List<Map<String, dynamic>>> _getList(String endpoint) async {
    try {
      final response = await http.get(
        Uri.parse('$backendBaseUrl$endpoint'),
        headers: _authHeaders(),
      );

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (decoded is List) {
          return decoded.cast<Map<String, dynamic>>();
        }
      }

      throw Exception('Backend request failed: ${response.statusCode}');
    } catch (_) {
      if (endpoint == '/api/supabase/students') {
        final response = await Supabase.instance.client.from('students').select();
        return List<Map<String, dynamic>>.from(response as List);
      }
      if (endpoint == '/api/supabase/rooms') {
        final response = await Supabase.instance.client.from('rooms').select();
        return List<Map<String, dynamic>>.from(response as List);
      }
      if (endpoint == '/api/supabase/contracts') {
        final response = await Supabase.instance.client
            .from('contracts')
            .select('*, students!inner(*), rooms!inner(*)');
        return List<Map<String, dynamic>>.from(response as List);
      }
      if (endpoint == '/api/supabase/payments') {
        final response = await Supabase.instance.client
            .from('payments')
            .select('*, contracts(*, students(*))');
        return List<Map<String, dynamic>>.from(response as List);
      }

      return [];
    }
  }
}
