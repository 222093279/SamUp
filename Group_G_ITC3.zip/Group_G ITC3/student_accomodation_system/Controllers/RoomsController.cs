using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using student_accomodation_system.Models;

namespace student_accomodation_system.Controllers
{
    public class RoomsController : Controller
    {
        private static readonly List<Room> rooms = new List<Room>
        {
            new Room { Id = 1, RoomNumber = "A101", Description = "Single room with study desk", Status = "Available" },
            new Room { Id = 2, RoomNumber = "A102", Description = "Single room near common area", Status = "Occupied" }
        };

        public ActionResult Index() => View(rooms);
        public ActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Room room)
        {
            if (!ModelState.IsValid) return View(room);
            if (rooms.Any(r => r.RoomNumber.Equals(room.RoomNumber, System.StringComparison.OrdinalIgnoreCase)))
            {
                ModelState.AddModelError("RoomNumber", "A room with this number already exists.");
                return View(room);
            }
            room.Id = rooms.Count == 0 ? 1 : rooms.Max(r => r.Id) + 1;
            rooms.Add(room);
            TempData["Success"] = "Room added successfully.";
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            var room = rooms.FirstOrDefault(r => r.Id == id);
            return room == null ? (ActionResult)HttpNotFound() : View(room);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Room room)
        {
            if (!ModelState.IsValid) return View(room);
            var existing = rooms.FirstOrDefault(r => r.Id == room.Id);
            if (existing == null) return HttpNotFound();
            if (rooms.Any(r => r.Id != room.Id && r.RoomNumber.Equals(room.RoomNumber, System.StringComparison.OrdinalIgnoreCase)))
            {
                ModelState.AddModelError("RoomNumber", "A room with this number already exists.");
                return View(room);
            }
            existing.RoomNumber = room.RoomNumber;
            existing.Description = room.Description;
            existing.Status = room.Status;
            TempData["Success"] = "Room updated successfully.";
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            var room = rooms.FirstOrDefault(r => r.Id == id);
            return room == null ? (ActionResult)HttpNotFound() : View(room);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var room = rooms.FirstOrDefault(r => r.Id == id);
            if (room == null) return HttpNotFound();
            rooms.Remove(room);
            TempData["Success"] = "Room deleted successfully.";
            return RedirectToAction("Index");
        }
    }
}
