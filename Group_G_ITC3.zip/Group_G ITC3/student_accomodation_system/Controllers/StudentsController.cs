using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using student_accomodation_system.Models;

namespace student_accomodation_system.Controllers
{
    public class StudentsController : Controller
    {
        private static readonly List<Student> students = new List<Student>
        {
            new Student { Id = 1, FullName = "John Doe", Phone = "123456789", Address = "123 Street" },
            new Student { Id = 2, FullName = "Jane Smith", Phone = "987654321", Address = "456 Avenue" }
        };

        public ActionResult Index() => View(students);

        public ActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Student student)
        {
            if (!ModelState.IsValid) return View(student);
            student.Id = students.Count == 0 ? 1 : students.Max(s => s.Id) + 1;
            students.Add(student);
            TempData["Success"] = "Student added successfully.";
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            var student = students.FirstOrDefault(s => s.Id == id);
            return student == null ? (ActionResult)HttpNotFound() : View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Student student)
        {
            if (!ModelState.IsValid) return View(student);
            var existing = students.FirstOrDefault(s => s.Id == student.Id);
            if (existing == null) return HttpNotFound();
            existing.FullName = student.FullName;
            existing.Phone = student.Phone;
            existing.Address = student.Address;
            TempData["Success"] = "Student updated successfully.";
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            var student = students.FirstOrDefault(s => s.Id == id);
            return student == null ? (ActionResult)HttpNotFound() : View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var student = students.FirstOrDefault(s => s.Id == id);
            if (student == null) return HttpNotFound();
            students.Remove(student);
            TempData["Success"] = "Student deleted successfully.";
            return RedirectToAction("Index");
        }
    }
}
