using System.Web.Mvc;

namespace student_accomodation_system.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index() { return View(); }
        public ActionResult About() { return View(); }
        public ActionResult Contact() { return View(); }
    }
}
