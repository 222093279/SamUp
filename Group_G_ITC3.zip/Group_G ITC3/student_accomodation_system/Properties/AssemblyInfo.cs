using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("student_accomodation_system")]
[assembly: AssemblyDescription("Student Accommodation System - ASP.NET MVC")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("student_accomodation_system")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
