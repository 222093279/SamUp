<%@ Application Codebehind="Global.asax.cs" Inherits="student_accomodation_system.MvcApplication" Language="C#" %>
