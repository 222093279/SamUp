GROUP_G ITC3 - STUDENT ACCOMMODATION SYSTEM

Open student_accomodation_system.sln in Visual Studio 2022.

Requirements:
- Visual Studio 2022 with ASP.NET and web development workload
- .NET Framework 4.8 developer pack
- NuGet package restore enabled

Run:
1. Open the .sln file.
2. Restore NuGet packages if Visual Studio asks.
3. Build > Rebuild Solution.
4. Press Ctrl+F5 or F5.

Features:
- Home/About/Contact pages
- Student CRUD (Create, Read, Edit, Delete)
- Room CRUD (Create, Read, Edit, Delete)
- Validation and anti-forgery protection
- Duplicate room-number validation
- Correct ID generation after records are deleted
- Bootstrap-based layout

Note: The assignment requested in-memory demo data, so records reset when the application restarts. A database can be added later.
